#include "images.h"

const ext_img_desc_t images[18] = {
    { "UI Elements 240x320", &img_ui_elements_240x320 },
    { "klingon48x48", &img_klingon48x48 },
    { "UI Elements 240x320 Transparent", &img_ui_elements_240x320_transparent },
    { "LCARS 240x320 - middle", &img_lcars_240x320___middle },
    { "LCARS 240x320 - small bottom", &img_lcars_240x320___small_bottom },
    { "LCARS 240x320 - small top", &img_lcars_240x320___small_top },
    { "LCARS 240x320 - top", &img_lcars_240x320___top },
    { "UI Element - Main Divider", &img_ui_element___main_divider },
    { "UI Element - Subdivider", &img_ui_element___subdivider },
    { "UI Element - Icons", &img_ui_element___icons },
    { "UI Element - Left Brace", &img_ui_element___left_brace },
    { "img_Head_0", &img_img_head_0 },
    { "img_Head_1", &img_img_head_1 },
    { "img_Head_2", &img_img_head_2 },
    { "img_Head_3", &img_img_head_3 },
    { "img_Background_0", &img_img_background_0 },
    { "img_Background_1", &img_img_background_1 },
    { "img_Background_2", &img_img_background_2 },
};
