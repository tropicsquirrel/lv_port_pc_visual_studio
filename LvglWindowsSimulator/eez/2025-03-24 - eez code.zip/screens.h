#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _objects_t {
    lv_obj_t *main;
    lv_obj_t *avatar;
    lv_obj_t *profile;
    lv_obj_t *mission;
    lv_obj_t *contacts;
    lv_obj_t *settings;
    lv_obj_t *info;
    lv_obj_t *obj0;
    lv_obj_t *obj1;
    lv_obj_t *obj2;
    lv_obj_t *obj3;
    lv_obj_t *obj4;
    lv_obj_t *obj5;
    lv_obj_t *obj6;
    lv_obj_t *obj7;
    lv_obj_t *obj8;
    lv_obj_t *obj9;
    lv_obj_t *obj10;
    lv_obj_t *obj11;
    lv_obj_t *obj12;
    lv_obj_t *obj13;
    lv_obj_t *obj14;
    lv_obj_t *obj15;
    lv_obj_t *obj16;
    lv_obj_t *obj17;
    lv_obj_t *obj18;
    lv_obj_t *obj19;
    lv_obj_t *obj20;
    lv_obj_t *obj21;
    lv_obj_t *obj22;
    lv_obj_t *obj23;
    lv_obj_t *obj24;
    lv_obj_t *obj25;
    lv_obj_t *obj26;
    lv_obj_t *obj27;
    lv_obj_t *obj28;
    lv_obj_t *obj29;
    lv_obj_t *obj30;
    lv_obj_t *obj31;
    lv_obj_t *obj32;
    lv_obj_t *obj33;
    lv_obj_t *obj34;
    lv_obj_t *obj35;
    lv_obj_t *obj36;
    lv_obj_t *obj37;
    lv_obj_t *obj38;
    lv_obj_t *obj39;
    lv_obj_t *obj40;
    lv_obj_t *obj41;
    lv_obj_t *pip_right;
    lv_obj_t *pip_right_mid;
    lv_obj_t *pip_left_mid;
    lv_obj_t *pip_left;
    lv_obj_t *ctr_mission;
    lv_obj_t *ctr_crew;
    lv_obj_t *ctr_info;
    lv_obj_t *ctr_settings;
    lv_obj_t *ctr_home;
    lv_obj_t *obj42;
    lv_obj_t *ctr_profile;
    lv_obj_t *flavor_main1;
    lv_obj_t *flavor_main2;
    lv_obj_t *flavor_main3;
    lv_obj_t *flavor_main4;
    lv_obj_t *flavor_main5;
    lv_obj_t *flavor_main6;
    lv_obj_t *flavor_main7;
    lv_obj_t *flavor_side1;
    lv_obj_t *flavor_side2;
    lv_obj_t *flavor_side3;
    lv_obj_t *flavor_side4;
    lv_obj_t *obj43;
    lv_obj_t *roller_avatar_component;
    lv_obj_t *ctr_mission_9;
    lv_obj_t *ctr_crew_7;
    lv_obj_t *ctr_info_7;
    lv_obj_t *ctr_settings_7;
    lv_obj_t *ctr_home_1;
    lv_obj_t *ctr_profile_7;
    lv_obj_t *lbl_random_numbers;
    lv_obj_t *tmp;
    lv_obj_t *img_background;
    lv_obj_t *img_hair_back;
    lv_obj_t *img_hair;
    lv_obj_t *img_ridges;
    lv_obj_t *img_accessories;
    lv_obj_t *img_borg;
    lv_obj_t *img_clothes;
    lv_obj_t *img_head;
    lv_obj_t *img_markings;
    lv_obj_t *img_beard;
    lv_obj_t *img_mouth;
    lv_obj_t *img_mustache;
    lv_obj_t *img_eyes;
    lv_obj_t *img_nose;
    lv_obj_t *slider_avatar_red;
    lv_obj_t *slider_avatar_green;
    lv_obj_t *slider_avatar_blue;
    lv_obj_t *slider_avatar_intensity;
    lv_obj_t *obj44;
    lv_obj_t *btn_avatar_prev;
    lv_obj_t *obj45;
    lv_obj_t *btn_avatar_next;
    lv_obj_t *lbl_avatar_item_id;
    lv_obj_t *obj46;
    lv_obj_t *obj47;
    lv_obj_t *pip_right_2;
    lv_obj_t *pip_right_mid_2;
    lv_obj_t *pip_left_mid_2;
    lv_obj_t *pip_left_2;
    lv_obj_t *ctr_mission_2;
    lv_obj_t *ctr_crew_2;
    lv_obj_t *ctr_info_2;
    lv_obj_t *ctr_settings_2;
    lv_obj_t *ctr_profile_2;
    lv_obj_t *obj48;
    lv_obj_t *flavor_main1_2;
    lv_obj_t *flavor_main2_2;
    lv_obj_t *flavor_main3_2;
    lv_obj_t *flavor_main4_2;
    lv_obj_t *flavor_main5_2;
    lv_obj_t *flavor_main6_2;
    lv_obj_t *flavor_main7_2;
    lv_obj_t *flavor_side1_2;
    lv_obj_t *flavor_side2_2;
    lv_obj_t *flavor_side3_2;
    lv_obj_t *flavor_side4_2;
    lv_obj_t *obj49;
    lv_obj_t *pip_right_3;
    lv_obj_t *pip_right_mid_3;
    lv_obj_t *pip_left_mid_3;
    lv_obj_t *pip_left_3;
    lv_obj_t *ctr_mission_5;
    lv_obj_t *ctr_crew_3;
    lv_obj_t *ctr_info_3;
    lv_obj_t *ctr_settings_3;
    lv_obj_t *ctr_profile_3;
    lv_obj_t *obj50;
    lv_obj_t *flavor_main1_3;
    lv_obj_t *flavor_main2_3;
    lv_obj_t *flavor_main3_3;
    lv_obj_t *flavor_main4_3;
    lv_obj_t *flavor_main5_3;
    lv_obj_t *flavor_main6_3;
    lv_obj_t *flavor_main7_3;
    lv_obj_t *flavor_side1_3;
    lv_obj_t *flavor_side2_3;
    lv_obj_t *flavor_side3_3;
    lv_obj_t *flavor_side4_3;
    lv_obj_t *obj51;
    lv_obj_t *pip_right_4;
    lv_obj_t *pip_right_mid_4;
    lv_obj_t *pip_left_mid_4;
    lv_obj_t *pip_left_4;
    lv_obj_t *ctr_mission_6;
    lv_obj_t *ctr_crew_4;
    lv_obj_t *ctr_info_4;
    lv_obj_t *ctr_settings_4;
    lv_obj_t *ctr_profile_4;
    lv_obj_t *obj52;
    lv_obj_t *flavor_main1_4;
    lv_obj_t *flavor_main2_4;
    lv_obj_t *flavor_main3_4;
    lv_obj_t *flavor_main4_4;
    lv_obj_t *flavor_main5_4;
    lv_obj_t *flavor_main6_4;
    lv_obj_t *flavor_main7_4;
    lv_obj_t *flavor_side1_4;
    lv_obj_t *flavor_side2_4;
    lv_obj_t *flavor_side3_4;
    lv_obj_t *flavor_side4_4;
    lv_obj_t *obj53;
    lv_obj_t *pip_right_5;
    lv_obj_t *pip_right_mid_5;
    lv_obj_t *pip_left_mid_5;
    lv_obj_t *pip_left_5;
    lv_obj_t *ctr_mission_7;
    lv_obj_t *ctr_crew_5;
    lv_obj_t *ctr_info_5;
    lv_obj_t *ctr_settings_5;
    lv_obj_t *ctr_profile_5;
    lv_obj_t *obj54;
    lv_obj_t *flavor_main1_5;
    lv_obj_t *flavor_main2_5;
    lv_obj_t *flavor_main3_5;
    lv_obj_t *flavor_main4_5;
    lv_obj_t *flavor_main5_5;
    lv_obj_t *flavor_main6_5;
    lv_obj_t *flavor_main7_5;
    lv_obj_t *flavor_side1_5;
    lv_obj_t *flavor_side2_5;
    lv_obj_t *flavor_side3_5;
    lv_obj_t *flavor_side4_5;
    lv_obj_t *obj55;
    lv_obj_t *pip_right_6;
    lv_obj_t *pip_right_mid_6;
    lv_obj_t *pip_left_mid_6;
    lv_obj_t *pip_left_6;
    lv_obj_t *ctr_mission_8;
    lv_obj_t *ctr_crew_6;
    lv_obj_t *ctr_info_6;
    lv_obj_t *ctr_settings_6;
    lv_obj_t *ctr_profile_6;
    lv_obj_t *obj56;
    lv_obj_t *flavor_main1_6;
    lv_obj_t *flavor_main2_6;
    lv_obj_t *flavor_main3_6;
    lv_obj_t *flavor_main4_6;
    lv_obj_t *flavor_main5_6;
    lv_obj_t *flavor_main6_6;
    lv_obj_t *flavor_main7_6;
    lv_obj_t *flavor_side1_6;
    lv_obj_t *flavor_side2_6;
    lv_obj_t *flavor_side3_6;
    lv_obj_t *flavor_side4_6;
    lv_obj_t *obj57;
} objects_t;

extern objects_t objects;

enum ScreensEnum {
    SCREEN_ID_MAIN = 1,
    SCREEN_ID_AVATAR = 2,
    SCREEN_ID_PROFILE = 3,
    SCREEN_ID_MISSION = 4,
    SCREEN_ID_CONTACTS = 5,
    SCREEN_ID_SETTINGS = 6,
    SCREEN_ID_INFO = 7,
};

void create_screen_main();
void tick_screen_main();

void create_screen_avatar();
void tick_screen_avatar();

void create_screen_profile();
void tick_screen_profile();

void create_screen_mission();
void tick_screen_mission();

void create_screen_contacts();
void tick_screen_contacts();

void create_screen_settings();
void tick_screen_settings();

void create_screen_info();
void tick_screen_info();

void tick_screen_by_id(enum ScreensEnum screenId);
void tick_screen(int screen_index);

void create_screens();


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/